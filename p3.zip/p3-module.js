
// Returns true if coin is an acceptable denomination
function validDenomination(coin){
return [1,5,10,25,50,100].indexOf(coin) !== -1;
}



function valueFromCoinObject(obj){
    const {denom = 0, count = 0} = obj;
    return validDenomination(denom) ? denom * count: 0;
}



let coin1 = {denom: 5, count: 15};
let coin2 = {denom: 4, count: 15}
let coin3 = {denom: 3, count: 15}
let coinArr = [coin1,coin2,coin3];
let coinArr2 = [coin1,coin2,coin3];

function valueFromArray(arr){
    return arr.reduce(
        (accumulator, current) => 
    { 
  return  Array.isArray(current) ? valueFromArray(current) : accumulator + valueFromCoinObject(current);
    },0
   ) ;
    };

    console.log(valueFromArray(coinArr))

function coinCount(...coinage){
    return valueFromArray(coinage);
}

console.log(valueFromArray(...[coinArr,coinArr2]));

console.log("{}", coinCount({denom: 5, count: 3}));
console.log("{}s", coinCount({denom: 5, count: 3},{denom: 10, count: 2}));
const coins = [{denom: 25, count: 2},{denom: 1, count: 7}];
console.log("...[{}]", coinCount(...coins));
console.log("[{}]", coinCount(coins));


export{
    coinCount
}